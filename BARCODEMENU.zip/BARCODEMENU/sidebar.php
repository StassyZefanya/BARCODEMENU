<div class="d-flex">
  <div class="bg-dark text-white p-3 vh-100" style="width:230px;">
    <h4 class="text-center mb-4">ADMIN PANEL</h4>

    <ul class="nav nav-pills flex-column gap-2">

      <li class="nav-item">
        <a href="dashboard.php" class="nav-link text-white">
        Daftar Pesanan
        </a>
      </li>

      <li class="nav-item">
        <a href="menu.php" class="nav-link text-white">
        Menu Edit Pesanan
        </a>
      </li>

      <li class="nav-item">
        <a href="orders.php" class="nav-link text-white">
        Database Pesanan
        </a>
      </li>

    </ul>
  </div>
